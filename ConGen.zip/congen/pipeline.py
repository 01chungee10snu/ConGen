
import asyncio
import json
import logging
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

from congen.agents.script_generator import ScriptGeneratorAgent
from congen.agents.image_generator import ImageGeneratorAgent
from congen.agents.video_generator import VideoGeneratorAgent
from congen.agents.audio_generator import AudioGeneratorAgent
from congen.models.script import Script
from congen.config.settings import settings

# 로거 설정
logger = logging.getLogger(__name__)


def get_media_duration(file_path: Path) -> float:
    """FFprobe로 미디어 파일 길이(초) 가져오기"""
    cmd = [
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(file_path)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0 and result.stdout.strip():
        return float(result.stdout.strip())
    return 0.0


class VideoGenerationPipeline:
    """
    교육 영상 제작을 위한 전체 파이프라인 관리자
    
    파이프라인 단계:
    1. 스크립트 생성 (Gemini)
    2. 이미지 생성 (Nano Banana Pro)
    3. 오디오 생성 (ElevenLabs)
    4. 비디오 생성 (Veo 3.1)
    5. 최종 조립 (FFmpeg)
    """
    
    def __init__(self):
        self.script_agent = ScriptGeneratorAgent()
        self.image_agent = ImageGeneratorAgent()
        self.video_agent = VideoGeneratorAgent()
        self.audio_agent = AudioGeneratorAgent()
        
    def _create_output_dir(self, topic: str) -> Path:
        """타임스탬프 기반 출력 디렉토리 생성"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        sanitized_topic = "".join(c for c in topic if c.isalnum() or c in (' ', '_')).strip().replace(' ', '_')
        sanitized_topic = sanitized_topic[:30]
        
        output_dir = settings.OUTPUT_DIR / f"{timestamp}_{sanitized_topic}"
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir

    async def _generate_audio(self, script: Script, output_dir: Path):
        """오디오(TTS) 생성"""
        logger.info("🔊 Step 3: Generating Audio (ElevenLabs)...")
        audio_dir = output_dir / "3_audio"
        audio_dir.mkdir(exist_ok=True)
        
        for scene in script.scenes:
            narration = scene.audio.narration if scene.audio else ""
            if not narration:
                logger.warning(f"⚠️ Scene {scene.scene_id}: No narration, skipping audio.")
                continue
            
            audio_path = audio_dir / f"scene_{scene.scene_id:03d}.wav"
            
            try:
                saved_path = await self.audio_agent.run(narration, audio_path)
                scene.audio_path = str(saved_path)
                logger.info(f"   ✅ Audio saved: {audio_path.name}")
            except Exception as e:
                logger.error(f"❌ Failed to generate audio for Scene {scene.scene_id}: {e}")
        
        # 스크립트 업데이트
        script_path = output_dir / "1_script.json"
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(script.model_dump(), indent=2, ensure_ascii=False))
        logger.info("✅ Audio generation completed.")

    def _create_static_video(self, image_path: Path, audio_path: Optional[Path], output_path: Path):
        """이미지를 사용하여 정적 비디오 생성 (FFmpeg) - 비용 절감용"""
        duration = 5.0
        if audio_path and audio_path.exists():
            duration = get_media_duration(audio_path)
            # 오디오보다 약간 길게 잡아서 끊김 방지
            duration += 0.5
            
        cmd = [
            "ffmpeg", "-y",
            "-loop", "1",
            "-i", str(image_path),
            "-c:v", "libx264",
            "-t", str(duration),
            "-pix_fmt", "yuv420p",
            # 짝수 해상도 강제 (일부 플레이어 호환성)
            "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", 
            str(output_path)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"FFmpeg static video generation failed: {result.stderr}")
        return output_path

    async def _generate_videos(self, script: Script, output_dir: Path):
        """비디오 생성 (Veo 또는 FFmpeg)"""
        logger.info(f"🎥 Step 4: Generating Videos (Strategy: {settings.VEO_STRATEGY})...")
        videos_dir = output_dir / "4_videos"
        videos_dir.mkdir(exist_ok=True)
        
        audio_dir = output_dir / "3_audio"
        
        for scene in script.scenes:
            logger.info(f"   Processing video for Scene {scene.scene_id}...")
            
            if not scene.image_path or not Path(scene.image_path).exists():
                logger.warning(f"⚠️ Skipping Scene {scene.scene_id}: No image found.")
                continue
                
            video_path = videos_dir / f"scene_{scene.scene_id:03d}.mp4"
            
            if video_path.exists():
                logger.info(f"   Video already exists: {video_path}")
                scene.video_path = str(video_path)
                continue
            
            # 오디오 경로 확인 (길이 계산용)
            audio_path = audio_dir / f"scene_{scene.scene_id:03d}.wav"
            if not audio_path.exists():
                audio_path = None
            
            try:
                # 전략에 따른 분기
                if settings.VEO_STRATEGY == "none":
                    # 비용 절감 모드: FFmpeg로 정적 영상 생성
                    logger.info(f"   Creating static video (Cost: $0) for Scene {scene.scene_id}")
                    saved_path = await asyncio.to_thread(
                        self._create_static_video, 
                        Path(scene.image_path), 
                        audio_path, 
                        video_path
                    )
                else:
                    # Veo 사용 (full 모드 등)
                    # TODO: hybrid 모드 구현 필요 (중요도에 따라 분기)
                    logger.info(f"   Generating AI video (Veo) for Scene {scene.scene_id}")
                    saved_path = await self.video_agent.run(
                        prompt=scene.visual.description,
                        image_path=Path(scene.image_path),
                        output_path=video_path
                    )
                    await asyncio.sleep(10)  # Rate Limit 방지

                scene.video_path = str(saved_path)
                
            except Exception as e:
                logger.error(f"❌ Failed to generate video for Scene {scene.scene_id}: {e}")
                # 실패 시 폴백으로 정적 영상 시도
                try:
                    logger.info("   Attempting fallback to static video...")
                    self._create_static_video(Path(scene.image_path), audio_path, video_path)
                    scene.video_path = str(video_path)
                except Exception as fallback_error:
                    logger.error(f"   ❌ Fallback also failed: {fallback_error}")
                
        # 스크립트 업데이트
        script_path = output_dir / "1_script.json"
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(script.model_dump(), indent=2, ensure_ascii=False))
        logger.info("✅ Video generation completed.")

    async def _assemble_final_video(self, script: Script, output_dir: Path):
        """최종 영상 조립 (FFmpeg)"""
        logger.info("🎬 Step 5: Assembling Final Video (FFmpeg)...")
        
        video_dir = output_dir / "4_videos"
        audio_dir = output_dir / "3_audio"
        temp_dir = output_dir / "temp"
        temp_dir.mkdir(exist_ok=True)
        
        # 사용 가능한 씬 확인
        available_scenes = []
        for scene in script.scenes:
            video_path = video_dir / f"scene_{scene.scene_id:03d}.mp4"
            audio_path = audio_dir / f"scene_{scene.scene_id:03d}.wav"
            
            if video_path.exists() and audio_path.exists():
                audio_duration = get_media_duration(audio_path)
                available_scenes.append({
                    "scene_id": scene.scene_id,
                    "video": video_path,
                    "audio": audio_path,
                    "audio_duration": audio_duration
                })
        
        if not available_scenes:
            logger.warning("⚠️ No complete scenes for assembly.")
            return
        
        # 각 씬 합치기
        merged_files = []
        for scene_data in available_scenes:
            scene_id = scene_data["scene_id"]
            merged_path = temp_dir / f"merged_{scene_id:03d}.mp4"
            
            cmd = [
                "ffmpeg", "-y",
                "-stream_loop", "-1",
                "-i", str(scene_data["video"]),
                "-i", str(scene_data["audio"]),
                "-c:v", "libx264",
                "-c:a", "aac",
                "-map", "0:v:0",
                "-map", "1:a:0",
                "-t", str(scene_data["audio_duration"]),
                "-shortest",
                str(merged_path)
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                merged_files.append(merged_path)
                logger.info(f"   ✅ Merged scene {scene_id}")
            else:
                logger.error(f"   ❌ Failed to merge scene {scene_id}")
        
        if not merged_files:
            logger.error("❌ No merged files created.")
            return
        
        # concat 리스트 생성
        concat_list_path = temp_dir / "concat_list.txt"
        with open(concat_list_path, "w", encoding="utf-8") as f:
            for merged_file in merged_files:
                f.write(f"file '{merged_file.name}'\n")
        
        # 최종 출력
        final_output = output_dir / "final_video.mp4"
        cmd = [
            "ffmpeg", "-y",
            "-f", "concat",
            "-safe", "0",
            "-i", str(concat_list_path),
            "-c", "copy",
            str(final_output)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(temp_dir))
        
        if result.returncode == 0:
            duration = get_media_duration(final_output)
            size_mb = final_output.stat().st_size / 1024 / 1024
            logger.info(f"✅ Final video created: {final_output}")
            logger.info(f"   Duration: {duration:.1f}s, Size: {size_mb:.2f} MB")
        else:
            logger.error(f"❌ Final assembly failed: {result.stderr}")

    async def run(self, topic: str) -> Path:
        """
        전체 파이프라인 실행
        
        1. 스크립트 생성
        2. 이미지 생성
        3. 오디오 생성 (TTS)
        4. 비디오 생성 (Veo)
        5. 최종 조립 (FFmpeg)
        """
        logger.info(f"🚀 Starting pipeline for topic: {topic}")
        
        # 1. 출력 디렉토리 생성
        output_dir = self._create_output_dir(topic)
        logger.info(f"📂 Output directory: {output_dir}")
        
        # 2. 스크립트 생성
        logger.info("📝 Step 1: Generating Script...")
        script = await self.script_agent.run(topic)
        
        script_path = output_dir / "1_script.json"
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(script.model_dump(), indent=2, ensure_ascii=False))
        logger.info(f"✅ Script saved to: {script_path}")
        
        # 3. 이미지 생성
        logger.info("🎨 Step 2: Generating Images...")
        images_dir = output_dir / "2_scenes"
        images_dir.mkdir(exist_ok=True)
        
        for scene in script.scenes:
            logger.info(f"   Generating image for Scene {scene.scene_id}...")
            image_path = images_dir / f"scene_{scene.scene_id:03d}.png"
            
            enhanced_prompt = f"Educational illustration, high quality, 4k, {scene.visual.description}"
            
            try:
                saved_path = await self.image_agent.run(enhanced_prompt, image_path)
                scene.image_path = str(saved_path)
            except Exception as e:
                logger.error(f"❌ Failed to generate image for Scene {scene.scene_id}: {e}")
                
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(json.dumps(script.model_dump(), indent=2, ensure_ascii=False))
        logger.info("✅ Image generation completed.")
        
        # 4. 오디오 생성
        await self._generate_audio(script, output_dir)
        
        # 5. 비디오 생성
        await self._generate_videos(script, output_dir)
        
        # 6. 최종 조립
        await self._assemble_final_video(script, output_dir)
        
        logger.info(f"🎉 Pipeline finished successfully! Results in: {output_dir}")
        return output_dir

    async def run_from_existing(self, output_dir: Path):
        """기존 결과 폴더에서 파이프라인 재개"""
        logger.info(f"🚀 Resuming pipeline from: {output_dir}")
        
        script_path = output_dir / "1_script.json"
        if not script_path.exists():
            raise FileNotFoundError(f"Script not found at {script_path}")
            
        with open(script_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            script = Script(**data)
        
        # 비디오 생성 단계로 바로 이동
        await self._generate_videos(script, output_dir)
        
        # 최종 조립
        await self._assemble_final_video(script, output_dir)
        
        logger.info(f"🎉 Pipeline resumed and finished! Results in: {output_dir}")
        return output_dir


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    logging.basicConfig(level=logging.INFO)
    
    async def main():
        pipeline = VideoGenerationPipeline()
        await pipeline.run("통계 기초: 평균, 분산, 표준편차")
        
    asyncio.run(main())
